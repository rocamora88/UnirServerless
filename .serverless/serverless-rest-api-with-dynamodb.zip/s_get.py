import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='rocamora88',
    application_name='todo-list-serverless',
    app_uid='BZkHRyFHXN49c0DPjT',
    org_uid='2e9834ed-7618-4a20-9039-78bc8cd96f54',
    deployment_uid='591794cf-7202-4c7b-bcc8-4934ac394fc1',
    service_name='serverless-rest-api-with-dynamodb',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='4.4.2',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'serverless-rest-api-with-dynamodb-dev-get', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('todos/get.get')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
